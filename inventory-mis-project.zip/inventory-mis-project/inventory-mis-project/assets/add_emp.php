<?php

include("include/header_links.php");
include("include/connection.php");

$name="";
$fname="";
$surname="";
$job="";
if(isset($_POST['subbtn'])){
    if(!empty($_POST['name'])){
        $name=$_POST['name'];
    }
    if(!empty($_POST['fname'])){
        $fname=$_POST['fname'];
    }
    if(!empty($_POST['surname'])){
        $surname=$_POST['surname'];
    }
    if(!empty($_POST['job'])){
        $job=$_POST['job'];
    }
    $sql = "INSERT INTO employees VALUE(Null,'$name','$fname','$surname','$job')";
    if(mysqli_query($c,$sql)){
        echo "ریکارد موفقانه اضافه شد";
    }
    else{
        echo "اضافه کردن معلومات به مشکل بر خورد";
    }
}
?>
    <div class="container-fluid">
        <br>
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="menu">
                <ul class="nav nav-pills">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">برگشت</a>
                    </li>
                </ul>
            </div>
        </div>
        <br>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-2"></div>
                <div class=" col-lg-8 col-md-8" dir="rtl" style="border: 1px solid  rgb(217, 226, 226); border-radius: 10px; padding-top: 20px;">
                    <h3 class="title" dir="rtl" style="text-align: center; ">  اضافه کردن کارمند جدید </h3>
                    <hr>
                    <form  role="form" method="post" action="">
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="name">نام :</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="name" name="name" placeholder=" ">
                            </div>

                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="name">نام پدر:</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="name" name="fname" placeholder=" ">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="name">تخلص :</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="name" name="surname" placeholder="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="name">وظیفه:</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="name" name="job" placeholder="">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-10">
                                <button type="submit" name="subbtn" class="btn btn-success btn-block">اضافه کردن</button>
                            </div>
                        </div>

                    </form>
                </div>
                <div class="col-lg-2"></div>
            </div>
        </div>
    </div>
<?php
include("include/footer_links.php");

?>