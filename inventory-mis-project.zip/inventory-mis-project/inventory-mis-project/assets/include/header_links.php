<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8"/>
    <title>Inventory</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/bootstrap-rtl.min.css" />
    <link rel="stylesheet" href="css/custom.css" />

    <link rel="stylesheet" type="text/css" href="css/style.css">


</head>
<body>