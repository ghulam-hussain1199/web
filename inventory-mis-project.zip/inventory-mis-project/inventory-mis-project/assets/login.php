<?php
	session_start();
	if(isset($_POST["username"])){
	$my_user = $_POST["username"];	
	$my_pass = $_POST["password"];	
		if($my_user== "admin" && $my_pass="123"){
			$_SESSION["ورود"] = $my_user;
			$_SESSION["ورود "] = 	$my_pass;
			header("location:index.php");
	}else{
		header("location:login.php?error=loginfaild");
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>ورود به سیستم</title>
	<meta charset="utf-8">
	<meta name="viewport" content="widtd= device - width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/login.css">
</head>

<body id="contents">
	<div id="loginBox">
		<img class="loginIcon" src="image/user_male_50px.png">
			<h2 class="title"> ورود به سیستم</h2>
			<form method="post">
				<p dir = "rtl">نام کاربر: </p>
				<input type="text" name="username" placeholder="نام تان را وارید کنید" dir = "rtl">	
				<p dir = "rtl">پسورد کاربر: </p>
				<input type="password" name="password" placeholder="پسورد تان را وارید کنید" dir = "rtl">
				<?php if(isset($_GET["error"])){ ?>
					<div style="color: red; font-size: 16px; text-align:center; font-weight: bold" >
						پسورد یا نام شما نادرست است
					</div>
				<?php } ?>
				<?php if(isset($_GET["login"])){ ?>
					<div style="color: red; font-size: 16px; padding: 5px; text-align:center; font-weight: bold">
					اول داخل شوید
					</div>
				<?php } ?>
				<input type="submit" name="sumbit" value="ورود">
			</form>	
</div>
</body>
</html>