<?php

include("include/header_links.php");
include("include/connection.php");

if(!empty($_POST['search'])){
    $search = $_POST['search'];
    $sql = " SELECT * FROM employees WHERE CONCAT(emp_name,emp_fname,emp_surname,emp_job) Like '%$search%'";
    $results = mysqli_query($c,$sql);
} else{
    $sql = " SELECT * FROM employees";
    $results = mysqli_query($c,$sql);
}
?>


    <div class="container-fluid">
         <div class="row" id="top" style="padding: 40px 0px">
        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12" id="logo">
            <img class="igm-responsive" src="image/3DFX_MRT.png" style="height: 50px; width: 100%;" alt="لوگو" />
        </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">

            </div>
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12" id="dept_name">
                خدمات نرم افزاری
            </div>

        </div>
        <br>
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="menu">
                <ul class="nav nav-pills">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">برگشت</a>
                    </li>

                </ul>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12" id="search">
                <form method="post" action="">
                    <div class="input-group"  style="padding-right: 30px">
                        <input class="form-control" placeholder="جستجو کنید" style="text-align: right" name="search">
                        <span class="input-group-btn">
				            	<button class="btn btn-primary" type="submit" name="">
					    	<span class="glyphicon glyphicon-search"></span>
					    	جستجو
					           </button>
					        </span>
                    </div>
                </form>
            </div>

            <div class="col-md-4">
                <h2 class="title" dir="rtl" style="text-align: right; padding-top: 10px;">لیست کارمندان</h2>
            </div>

        </div>
        <br>
        <div class="row" id="content">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 "dir="rtl" style="text-align: right" >
                <table class="table table-striped">
                    <thead>
                    <tr class="info">
                        <th>نام کارمند</th>
                        <th>نام پدر</th>
                        <th>تخلص</th>
                        <th>وظیفه</th>
                        <th>عملیات</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $results = mysqli_query($c,$sql);
                    if(mysqli_num_rows($results)>0){
                        while($row = mysqli_fetch_row($results)){
                            echo "<tr>";
                            echo "<td>".$row[1]."</td>";
                            echo "<td>".$row[2]."</td>";
                            echo "<td>".$row[3]."</td>";
                            echo "<td>".$row[4]."</td>";
                            echo "<td><a href='edit_emp.php?id=".$row[0]."'> اصلاح </a></td>";
                            echo "</tr>";
                        }
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php
include("include/footer_links.php");

?>