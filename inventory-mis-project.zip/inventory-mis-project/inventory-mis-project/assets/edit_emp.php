<?php

include("include/header_links.php");
include("include/connection.php");

$name = ""; $fname=""; $surname =""; $job = "";
$id = $_GET['id'];
if (isset($_POST["subbtn"])) {

    if (!empty($_POST["name"]) && !empty($_POST["fname"]) && !empty($_POST["surname"]) && !empty($_POST["job"])) {
        $name = $_POST["name"];
        $fname = $_POST["fname"];
        $surname = $_POST["surname"];
        $job = $_POST["job"];
    }

    $update = mysqli_query($c, "UPDATE employees SET emp_name ='$name',emp_fname = '$fname',emp_surname ='$surname',emp_job= '$job' WHERE emp_id = $id ");
    if ($update) {
        echo "موفقانه اپدیت شد";
        header("location:list_emp.php");
    }else{
        echo "معلومات اپدیت نشد";
        header("location:edit_emp.php");
    }

}else{

    $result = mysqli_query($c, "SELECT * FROM employees WHERE emp_id = $id");
    $row = mysqli_fetch_row($result);
}
?>
    <div class="container-fluid">
        <br>
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="menu">
                <ul class="nav nav-pills">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">برگشت</a>
                    </li>
                </ul>
            </div>
        </div>
        <br>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-2"></div>
                <div class=" col-lg-8 col-md-8" dir="rtl" style="border: 1px solid  rgb(217, 226, 226); border-radius: 10px; padding-top: 20px;">
                    <h3 class="title" dir="rtl" style="text-align: center; "> ویرایش کارمندان </h3>
                    <hr>
                    <form  role="form" method="post" action="">
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="name">نام :</label>
                            <div class="col-sm-10">
                                <input type="text" value="<?php if(!empty($row[1])){ echo $row[1]; } ?>"  class="form-control" id="name" name="name" placeholder=" ">
                            </div>

                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="name">نام پدر:</label>
                            <div class="col-sm-10">
                                <input type="text" value="<?php if(!empty($row[2])){ echo $row[2]; } ?>"  class="form-control" id="name" name="fname" placeholder=" ">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="name">تخلص :</label>
                            <div class="col-sm-10">
                                <input type="text" value="<?php if(!empty($row[3])){ echo $row[3]; } ?>"  class="form-control" id="name" name="surname" placeholder="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="name">وظیفه:</label>
                            <div class="col-sm-10">
                                <input type="text" value="<?php if(!empty($row[4])){ echo $row[4]; } ?>"  class="form-control" id="name" name="job" placeholder="">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-10">
                                <button type="submit" name="subbtn" class="btn btn-success btn-block">اضافه کردن</button>
                            </div>
                        </div>

                    </form>
                </div>
                <div class="col-lg-2"></div>
            </div>
        </div>
    </div>
<?php
include("include/footer_links.php");

?>